/* Null stubs for coprocessor precision settings */

int sprec(void)
{
    return 0;
}

int dprec(void)
{
    return 0;
}

int ldprec(void)
{
    return 0;
}
